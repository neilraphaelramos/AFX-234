import express from "express";
import mysql from "mysql";
import cors from "cors";

const app = express();

//This config only works on mysql xampp, workbench

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "test"
});

app.use(express.json());
app.use(cors())

db.connect((err) => {
    if (err) {
        console.log("Error connection to the mysql database:", err);
        return;
    }
    console.log("Database Connected!");
});

app.get("/", (req, res) => {
    res.json("Hello, this is backend!")
});

app.get("/user_table", (req, res) => {
    const sql = "select * from user_table";
    db.query(sql, (err, data) => {
        if (err) {
            return res.json(err)
        }
        return res.json(data)
    });
});

app.get("/user_table/:id", (req, res) => {
    const dataId = req.params.id; // Extract the ID from the request parameters
    const sql = "SELECT * FROM user_table WHERE id = ?"; // Parameterized query

    db.query(sql, [dataId], (err, data) => { // Pass the ID as an array
        if (err) {
            return res.status(500).json(err); // Send 500 status on error
        }
        if (data.length === 0) {
            return res.status(404).json("User not found!"); // Return 404 if no user found
        }
        return res.status(200).json(data[0]); // Send the first user (since it should be unique by ID)
    });
});

app.post("/user_table", (req, res) => {
    const q = "INSERT INTO `user_table`(`firstname`, `lastname`, `username`) VALUES (?, ?, ?)";
    const values = [
        req.body.fname,
        req.body.lname,
        req.body.uname,
    ];

    db.query(q, values, (err, data) => {
        if (err) {
            return res.status(500).json(err); // Send 500 status for errors
        }
        return res.status(201).json("Data has been uploaded!"); // Changed message
    });
    console.log("Data uploaded!")
});

app.delete("/user_table/:id", (req, res) => {
    const dataId = req.params.id;
    const q = "DELETE FROM user_table WHERE id = ?";

    db.query(q, [dataId], (err, data) => {
        if (err) {
            return res.status(500).json(err); // Send 500 status for errors
        }
        return res.status(201).json("Data has been deleted!"); // Updated message
    });
    console.log("Data Delete!")
});

app.put("/user_table/:id", (req, res) => {
    const dataId = req.params.id;
    const q = "UPDATE user_table SET firstname = ?, lastname = ?, username = ? WHERE id = ?"; // Fixed query

    const values = [
        req.body.fname,
        req.body.lname,
        req.body.uname,
    ];

    db.query(q, [...values, dataId], (err, data) => {
        if (err) {
            return res.status(500).json(err); // Send 500 status for errors
        }
        return res.status(200).json("Data has been updated!"); // Correct response message
    });
    console.log("Data Updated!");
});

app.listen(8800, () => {
    console.log("Connected to backend data on port 8800!");
});