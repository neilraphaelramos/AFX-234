import { BrowserRouter, Routes, Route } from "react-router-dom";
import TableData from "./components/pages/tableUser";
import AddForm from "./components/pages/addUser";
import UpdateForm from "./components/pages/updateUser";
import Mainloginadmin from "./components/pages/loginadmin";
import IntroPage from "./components/pages/introPage";
import DIsplayInfo from "./components/admincredentials/DIsplayInfo";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<IntroPage />} />
          <Route path="/Login" element={<Mainloginadmin />} />
          <Route path="/dashboard" element={<TableData />} />
          <Route path="/account" element={<DIsplayInfo />} />
          <Route path="/adduser" element={<AddForm />} />
          <Route path="/uduser/:id" element={<UpdateForm />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
