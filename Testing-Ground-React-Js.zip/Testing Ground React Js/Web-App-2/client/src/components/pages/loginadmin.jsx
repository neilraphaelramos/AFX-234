import React, { useState, useRef, useEffect, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Mainloginadmin = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    
    const navigate = useNavigate();
    const usernameRef = useRef(null);

    // Ref holding user credentials
    const userCredentials = useRef({
        username: 'Admin',
        password: 'Admin'
    });

    const handleSubmit = useCallback((e) => {
        e.preventDefault();

        // Simple validation
        if (!username || !password) {
            setError('Please fill in all fields');
            return;
        }

        setError('');

        // Check credentials against the ref
        if (username === userCredentials.current.username && password === userCredentials.current.password) {
            // Successful login
            console.log('Login successful!');
            navigate('/dashboard'); // Change to your desired route
        } else {
            // Invalid credentials
            setError('Invalid username or password');
        }
    }, [username, password, navigate]);

    useEffect(() => {
        // Focus on the username input when the component mounts
        usernameRef.current.focus();
    }, []);

    return (
        <div className="color-page d-flex justify-content-center align-items-center vh-100">
            <div className="card" style={{ width: '20rem' }}>
                <div className="card-body">
                    <h5 className="card-title text-center">Login</h5>
                    {error && <div className="alert alert-danger">{error}</div>}
                    <form onSubmit={handleSubmit} autoComplete='off'>
                        <div className="mb-3">
                            <label htmlFor="username" className="form-label">Username</label>
                            <input
                                type="text" // Change to 'text' for username
                                className="form-control"
                                id="username"
                                ref={usernameRef}
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="password" className="form-label">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Mainloginadmin;
