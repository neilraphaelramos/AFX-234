import axios from 'axios';
import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function UpdateForm() {
    const navigate = useNavigate();
    const location = useLocation();
    const dataid = location.pathname.split('/')[2];
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false);

    const [data, setData] = useState({
        fname: "",
        lname: "",
        uname: "",
    });

    useEffect(() => {
        const fetchAllData = async () => {
            try {
                const res = await axios.get(`http://localhost:8800/user_table/${dataid}`);
                console.log("Fetched Data:", res.data);

                setData({
                    fname: res.data.firstname || "",
                    lname: res.data.lastname || "",
                    uname: res.data.username || "",
                });
            } catch (err) {
                console.error(err);
                setError("Failed to fetch user data.");
            }
        };

        fetchAllData();
    }, [dataid]);

    const handleChange = useCallback((e) => {
        setData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    }, []);

    const handleUpdateClick = useCallback(() => {
        setShowModal(true);
    }, []);

    const confirmUpdate = useCallback(async () => {
        try {
            await axios.put(`http://localhost:8800/user_table/${dataid}`, data);
            navigate("/dashboard");
        } catch (err) {
            console.error(err);
            setError("Failed to update user data.");
        }
        setShowModal(false);
    }, [data, dataid, navigate]);

    return (
        <div className='form-container'>
            <h1 className='text-center'>Update User Account</h1>
            {error && <div className="alert alert-danger">{error}</div>}
            <form autoComplete='off'>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Firstname</label>
                    <input
                        type='text'
                        className="form-control"
                        name='fname'
                        value={data.fname}
                        onChange={handleChange}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Lastname</label>
                    <input
                        type='text'
                        className="form-control"
                        name='lname'
                        value={data.lname}
                        onChange={handleChange}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="username" className="form-label">Username</label>
                    <input
                        type='text'
                        className="form-control"
                        name='uname'
                        value={data.uname}
                        onChange={handleChange}
                    />
                </div>
                <div className="button-group">
                    <button type="button" className="btn btn-primary me-2" onClick={handleUpdateClick}>Update</button>
                    <Link to="/dashboard" className="btn btn-secondary">Back</Link>
                </div>
            </form>

            {/* Bootstrap Modal */}
            <div className={`modal ${showModal ? 'show' : ''}`} style={{ display: showModal ? 'block' : 'none' }} aria-hidden={!showModal}>
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Confirm Update</h5>
                            <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                        </div>
                        <div className="modal-body">
                            <p>Are you sure you want to update this item?</p>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                            <button type="button" className="btn btn-primary" onClick={confirmUpdate}>Update</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UpdateForm;
