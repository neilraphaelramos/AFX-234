import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';
import './style.css'

const IntroPage = () => {
    const navigate = useNavigate()
    const handleClick = () => {
        navigate("/Login")
    }

    return (
        <div className="color-page d-flex justify-content-center align-items-center vh-100">
            <div className="text-center">
                <h1>Welcome to Our Table User App</h1>
                <p>This is the introductory table user app page. Click below to proceed to the login page.</p>
                <button className="btn btn-primary" onClick={handleClick}>
                    Go to Login
                </button>
            </div>
        </div>
    )
}

export default IntroPage