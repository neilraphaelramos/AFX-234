import React, { useState, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './style.css';

const AddForm = () => {
    const [data, setData] = useState({
        fname: "",
        lname: "",
        uname: "",
    });

    const handleChange = useCallback((e) => {
        setData(prev => ({ ...prev, [e.target.name]: e.target.value })); // Update state based on input name
    }, []);

    const navigate = useNavigate();

    const handleClick = useCallback(async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:8800/user_table", data);
            navigate("/dashboard");
        } catch (err) {
            console.log(err);
        }
    }, [data, navigate]);

    return (
        <div className='form-container'>
            <h1 className='text-center'>Add User Account</h1>
            <form autoComplete='off'>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Firstname</label>
                    <input
                        type='text'
                        className="form-control"
                        name='fname'
                        value={data.fname} // Set value from state
                        onChange={handleChange}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Lastname</label>
                    <input
                        type='text'
                        className="form-control"
                        name='lname'
                        value={data.lname} // Set value from state
                        onChange={handleChange}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="username" className="form-label">Username</label>
                    <input
                        type='text'
                        className="form-control"
                        name='uname'
                        value={data.uname} // Set value from state
                        onChange={handleChange}
                    />
                </div>
                <div className="button-group">
                    <button type="submit" className="btn btn-primary me-2" onClick={handleClick}>Submit</button>
                    <Link to="/dashboard" className="btn btn-secondary">Back</Link>
                </div>
            </form>
        </div>
    );
};

export default AddForm;
