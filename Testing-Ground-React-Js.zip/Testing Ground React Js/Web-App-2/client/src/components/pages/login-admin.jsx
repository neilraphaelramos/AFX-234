import React from 'react'

const loginAdmin = () => {
  return (
    <div>login(admin)</div>
  )
}

export default loginAdmin(admin)