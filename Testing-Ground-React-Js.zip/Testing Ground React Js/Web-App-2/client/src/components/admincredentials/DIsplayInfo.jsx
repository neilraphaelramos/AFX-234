import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const DIsplayInfo = () => {
    const navigate = useNavigate()
    const handleClick = () => {
        navigate("/dashboard")
    }
    const accountDetails = {
        username: 'Admin',
        Role: 'Administrator',
      };
  return (
    <div className="container mt-5">
      <h1 className="text-center">Account Details</h1>
      <div className="card">
        <div className="card-body">
          <form>
            <div className="mb-3">
              <label htmlFor="username" className="form-label">Username</label>
              <input
                type="text"
                className="form-control"
                id="username"
                value={accountDetails.username}
                readOnly
              />
            </div>
            <div className="mb-3">
              <label htmlFor="role" className="form-label">Role</label>
              <input
                type="text"
                className="form-control"
                id="role"
                value={accountDetails.Role}
                readOnly
              />
            </div>
            <div className="text-center">
              <button type="button" className="btn btn-secondary" onClick={(handleClick)}>
                Back
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default DIsplayInfo